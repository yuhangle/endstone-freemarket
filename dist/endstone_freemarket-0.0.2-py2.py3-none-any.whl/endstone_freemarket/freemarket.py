from endstone.command import Command, CommandSender, CommandSenderWrapper
from endstone.plugin import Plugin
import json
import os
from endstone.form import ModalForm,Dropdown,Label,ActionForm,TextInput,Slider,MessageForm
from endstone.event import event_handler, PlayerInteractEvent
import re
import time
# 插件初始化部分

fmdata = "plugins/freemarket"
moneydata = "plugins/freemarket/moneydata.json"
marketdata = "plugins/freemarket/marketdata.json"

# 创建数据文件夹
if not os.path.exists(fmdata):
    os.makedirs(fmdata)
# 创建货币数据文件    
if not os.path.exists(moneydata):
    with open(moneydata, 'w',encoding='utf-8') as file:
        json.dump({}, file)
# 创建市场数据文件    
if not os.path.exists(marketdata):
    with open(marketdata, 'w',encoding='utf-8') as file:
        json.dump({}, file)
# 定义货币名
moneyname = "信用点"


class freemarket(Plugin):
    api_version = "0.5"
    
    def on_load(self) -> None:
        self.logger.info("on_load is called!")

    def on_enable(self) -> None:
        self.logger.info("on_enable is called!")
        self.last_command_time = 0  # 记录上次执行命令的时间
        # 监听事件
        self.register_events(self)

    def on_disable(self) -> None:
        self.logger.info("on_disable is called!")

    # 分割线
    
    # 用于用户注册的函数
    def add_user(self,playername:str,username:str,money=0):
        """
        注册用户信息
        playername: 玩家名
        username: 玩家注册的用户名
        money: 用户资金,默认为0
        """
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)
        # 注册用户信息
        data[playername] = {"username": username, "money": money}
        # 将修改后的数据写入文件
        with open(moneydata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"您已成功注册服务器交易账号,账号名为 {username}"
        return msg

    # 用于检测玩家是否注册过服务器交易账号的函数
    def testuser(self,playername:str):
        """
        检测玩家是否注册过服务器交易账号
        playername: 玩家名
        """  
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)
        # 检查玩家是否注册
        if playername not in data:
            return False
        else:
            return True
        
    # 用于用户资金变动的函数
    def change_money(self,playername:str,action:str,money=0):
        """
        用户资金变动
        playername: 玩家名
        action: 对用户资金的操作,增加为add,减少为less
        money: 用户资金的更改额度,默认为0
        """
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)
        # 获取玩家账户资金
        nowmoney = data[playername]["money"]
        # 对玩家资金进行运算
        if action == "add":
            aftermoney = nowmoney + money
        elif action == "less":
            aftermoney = nowmoney - money
        else:
            msg = "无经济操作"
            return msg
        # 更改玩家资金
        data[playername]["money"] = aftermoney
        # 将修改后的数据写入文件
        with open(moneydata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"玩家 {playername} 的账户已{"增加" if action == "add" else "减少"}了{money}{moneyname},现账户余额为{aftermoney}"
        return msg

    # 用于用户重命名的函数
    def rename_account(self,playername:str,username:str):
        """
        用户重命名
        playername: 玩家名
        username: 新用户名
        """
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)

        if data[playername]["username"] == username:
            msg = "新用户名与老用户名一致,无需更改"
            return msg
        old_username = data[playername]["username"]
        # 更改玩家用户名
        data[playername]["username"] = username
        # 将修改后的数据写入文件
        with open(moneydata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"玩家 {playername} 的账户 {old_username} 已重命名为 {username}"
        return msg

    # 用于删除用户的函数
    def del_account(self,playername:str):
        """
        删除玩家账户
        playername: 玩家名
        """
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)

        del data[playername]
        # 将修改后的数据写入文件
        with open(moneydata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"玩家 {playername} 的账户已被删除"
        return msg
    
    # 用于获取用户信息的函数
    def get_account_info(self,playername:str):
        """
        获取玩家账户信息
        playername: 玩家名
        """
        # 读取现有的经济数据
        with open(moneydata, "r",encoding='utf-8') as f:
            data = json.load(f)

        username = data[playername]["username"]
        money = data[playername]["money"]
        msg = {
            "username": username,
            "money": money
        }
        return msg
    
    # 市场部分函数
    
    # 用于上架商品的函数
    def add_goods(self,playername:str,goodsname:str,goodsnum:int,needname:str,neednum:int,tips="商家没有留下商品介绍"):
        """
        上架商品信息
        playername: 玩家名
        goodsname: 上架的商品信息
        goodsnum: 上架的商品数量
        needname: 交易结算介质 可为货币也可为物品
        neednum: 交易结算介质需要数额
        tips: 商品介绍
        """
        # 读取现有的市场数据
        with open(marketdata, "r",encoding='utf-8') as f:
            data = json.load(f)
        # 上架商品信息
        data[playername] = {"goodsname": goodsname, "goodsnum": goodsnum, "needname": needname, "neednum": neednum, "tips": tips}
        # 将修改后的数据写入文件
        with open(marketdata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"您已成功上架{goodsnum}单位个{playername}"
        return msg

    # 用于检测玩家现在是否有商品在卖
    def testgoods(self,playername:str):
        """
        检测玩家是否有商品在卖
        playername: 玩家名
        """  
        # 读取现有的经济数据
        with open(marketdata, "r",encoding='utf-8') as f:
            data = json.load(f)
        # 检查玩家是否注册
        if playername not in data:
            return False
        else:
            return True

    # 用于下架商品的函数
    def del_goods(self,playername:str):
        """
        下架商品
        playername: 玩家名
        """
        # 读取现有的经济数据
        with open(marketdata, "r",encoding='utf-8') as f:
            data = json.load(f)

        del data[playername]
        # 将修改后的数据写入文件
        with open(marketdata, "w",encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        msg = f"玩家 {playername} 的商品已下架"
        return msg
    
    # 用于获取商品信息的函数
    def get_goods_info(self,playername:str):
        """
        获取商品信息
        playername: 玩家名
        """
        # 读取现有的市场数据
        with open(marketdata, "r",encoding='utf-8') as f:
            data = json.load(f)

        goodsname = data[playername]["goodsname"]
        goodsnum = data[playername]["goodsnum"]
        needname = data[playername]["needname"]
        neednum = data[playername]["neednum"]
        tips = data[playername]["tips"]
        msg = {
            "goodsname": goodsname,
            "goodsnum": goodsnum,
            "needname": needname,
            "neednum": neednum,
            "tips": tips
        }
        return msg
    # 检查买家是否具有购买条件的函数
    def check_shopping(self,buyer,needname,neednum):
        """
        检查买家是否具有购买条件
        buyer: 买家玩家名
        needname: 需要的交易媒介
        neednum: 交易媒介的数量
        """
        # 获取玩家背包
        all_item = []
        for item_num in range(36):
            item = self.server.get_player(buyer).inventory.get_item(item_num)
            if item:  # 如果槽位不为空
                item_name = item.type
                item_amount = item.amount
                all_item.append({'num': item_num, 'item': item_name, 'amount': item_amount})
                
        # 检查买家背包中的物品是否满足价格
        for item_info in all_item:
            if item_info['item'] == needname and item_info['amount'] >= neednum:
                return True
            else:
                return False
            
    # 获取卖家快捷物品栏最右边的物品名称与数量的函数
    def get_seller_inventory(self,seller):
        """
        获取卖家快捷物品栏最右边的物品名称与数量
        sellr: 卖家玩家名
        """
        try:
            # 获取玩家背包
            item = self.server.get_player(seller).inventory.get_item(8)
            if item:  # 如果槽位不为空
                goodsname = item.type
                goodsnum = item.amount
                return goodsname,goodsnum
            else:
                return None,None
        except:
            return None,None
    
    # 分割线
    commands = {
        "account": {
            "description": "对玩家账号进行操作 --用法 /account 玩家名 操作:[add less create rename del] 金额/用户名",
            "usages": ["/account [msg: message] [msg: message] [msg: message]"],
            "permissions": ["freemarket.command.changemoney"],
        },
        "market": {
            "description": "打开市场菜单",
            "usages": ["/market"],
            "permissions": ["freemarket.command.market"],
        }
    }
    permissions = {
        "freemarket.command.account": {
            "description": "对玩家账号进行操作",
            "default": "op", 
        },
        "freemarket.command.market": {
            "description": "打开市场菜单",
            "default": True, 
        }
    }

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name == "account":
            try:
                playername = args[0]
                action = args[1]
                # 检查玩家是否存在账号
                if self.testuser(playername) == False:
                    # 操作为create时创建默认账号
                    if action == "create":
                        msg = self.add_user(playername,username="默认昵称",money=0)
                    else:
                        sender.send_error_message(f"玩家 {playername} 没有服务器交易账号")
                        return
                else:
                    if action == "add":
                        msg = self.change_money(playername,action,money=float(args[2]))
                    elif action == "less":
                        msg = self.change_money(playername,action,money=float(args[2]))
                    elif action == "create":
                        sender.send_error_message("该玩家的账号已存在,无需创建")
                        return
                    elif action == "rename":
                        msg = self.rename_account(playername,username=args[2])
                    elif action == "del":
                        msg = self.del_account(playername)
            except:
                sender.send_error_message("格式错误")
                return
                
            sender.send_message(f"{msg}")
            
        elif command.name == "market":
            # 账户信息子菜单
            def account_info():
                def on_click(sender):
                    if self.testuser(sender.name) == True:
                        # 重命名按钮
                        rename_button = ActionForm.Button(text="§l§5重命名账户",on_click=open_rename_sub())
                        # 用户信息展示
                        self.server.get_player(sender.name).send_form(ActionForm(
                            title=f"§l§5{sender.name}的用户信息",
                            content=f"§l§o§b用户名: {self.get_account_info(sender.name)["username"]}\n" + f"§l§o§b账户余额: {self.get_account_info(sender.name)["money"]}",
                            buttons=[rename_button]
                            )
                        )
                    else:
                        sender.send_error_message("您尚未拥有服务器交易账户,已为您自动创建")
                        sender.send_message(self.add_user(sender.name,username=f"默认昵称{sender.name}",money=0))
                return on_click
            # 账户重命名子菜单
            def open_rename_sub():
                def rename_sub(sender,json_str:str):
                    sender.send_message(self.rename_account(sender.name,json.loads(json_str)[0]))
                def on_click(sender):
                    self.server.get_player(sender.name).send_form(ModalForm(title="§4账户重命名界面",controls=[TextInput(label="新账户名",placeholder=self.get_account_info(sender.name)["username"],default_value=self.get_account_info(sender.name)["username"])],on_submit=rename_sub))
                return on_click
            
            # 交易市场菜单
            def market_menu():
                def on_click(sender):
                    form = ActionForm(
                        title="§l§b交易市场",
                        #content=f"§l§o§5一言：{hitokoto}，出处：{from_}",
                        #buttons=[button1,button2,button3,button4,button5]
                    )
                    with open(marketdata, "r",encoding='utf-8') as f:
                        goodsdata = json.load(f)
                    # 动态添加按钮并设置回调
                    for playername, words in goodsdata.items():
                        # 点击商品后打开店铺详情
                        def create_callback(username,goodsname = words["goodsname"],goodsnum = words["goodsnum"]):
                            def on_click(sender):
                                print(playername)
                                buy = ActionForm.Button(text="购买",on_click=open_buy_sub(playername))
                                goods_text = f"商品名称: {goodsname}  商品数量: {goodsnum}"
                                self.server.get_player(sender.name).send_form(
                                    ActionForm(
                                        title=f'§l§b{username}的店铺',
                                        content=goods_text,
                                        buttons=[buy]
                                    )
                                )
                                # 执行当前点击的按钮对应的指令
                                #sender.send_message(updated_menu[button_text]["text"])
                            return on_click
                        # 增加商品按钮
                        username=self.get_account_info(playername)["username"]
                        title = f"{words["goodsname"]} {words["tips"]}"
                        form.add_button(title,on_click=create_callback(username,words["goodsname"]))
                    self.server.get_player(sender.name).send_form(form)
                return on_click
            
            # 购买确认子菜单
            def open_buy_sub(playername):
                goodsname,goodsnum,needname,neednum,tips = self.get_goods_info(playername)["goodsname"],self.get_goods_info(playername)["goodsnum"],self.get_goods_info(playername)["needname"],self.get_goods_info(playername)["neednum"],self.get_goods_info(playername)["tips"]
                def buy_sub(sender,json_str:str):
                    buyer = sender.name
                    if self.check_shopping(buyer,needname,neednum) == True:
                            self.server.dispatch_command(CommandSenderWrapper(self.server.command_sender), f'clear "{sender.name}" {needname} 0 {neednum}')
                            self.server.dispatch_command(CommandSenderWrapper(self.server.command_sender), f'give "{sender.name}" {goodsname} {goodsnum}')
                            print(f'give "{sender.name}" {goodsname} 0 {goodsnum}')
                            self.del_goods(playername)
                    else:
                        sender.send_error_message("您的资产不足,购买失败")
                def on_click(sender):
                    self.server.get_player(sender.name).send_form(ModalForm(title="§4购买界面菜单",controls=[Label(text=f"您将要购买的商品为 {tips} {goodsname} 数量为 {goodsnum},价格为{needname} {neednum}单位.\n点击提交按钮确认交易,关闭窗口放弃交易")],on_submit=buy_sub))
                return on_click
            
            # 上架商品菜单
            def add_goods_menu():
                def on_click(sender):
                    form = ModalForm(
                        title="§l§b上架商品",
                        controls=[
                            Label(text=f"§l§o§5请将您要上架的商品放在快捷物品栏最右边,确认无误后点击上架按钮"),
                            Dropdown(label="选择交易结算方式",options=["钻石","绿宝石","黄金","铁锭",f"{moneyname}","自定义"]),
                            TextInput(label="当您选择自定义结算方式时,交易结算货币类型将以此处输入值为准,请确保该物品为Minecraft中的物品ID且无误,否则后果自负",placeholder="输入您的自定义结算物品ID",default_value="minecraft:emerald"),
                            Slider(label="选择交易货币数量",min=1,max=114,step=1)
                        ],
                        on_submit=open_add_sub
                    )
                    
                    if self.testgoods(sender.name) == True:
                        sender.send_error_message("您已有一件商品在卖,无法再上架新的商品")
                    else:
                        self.server.get_player(sender.name).send_form(form)
                return on_click
            
            # 上架确认子菜单
            def open_add_sub(player,json_str):
                seller = sender.name
                # 物品栏检查
                goodsname,goodsnum = self.get_seller_inventory(seller)
                if goodsname == None and goodsnum == None:
                    sender.send_error_message("你的快捷物品栏最右边没有物品")
                    return on_click
                # 获取商品信息
                goods_info_data = json.loads(json_str)
                # 定义映射关系
                # 当选择自定义时赋值为自定义值
                if goods_info_data[1] == 5:
                    needname = goods_info_data[2]
                else:
                    needname = goods_info_data[1]
                neednum = int(goods_info_data[3])
                
                def add_sub(sender,json_str:str):
                    tips = json.loads(json_str)[0]
                    sender.send_message(self.add_goods(seller,goodsname,goodsnum,needname,neednum,tips))
                def on_click(sender):
                    self.server.get_player(sender.name).send_form(ModalForm(title="§4上架商品界面菜单",controls=[Label(text=f"您将要上架的商品为 {goodsname} 数量为 {goodsnum},价格为{needname} {neednum}单位.\n点击提交按钮确认交易,关闭窗口放弃交易"),TextInput(label="请输入商品简介",default_value="该商家很懒,没有留下商品信息")],on_submit=add_sub))
                return on_click
            
            # 账户信息按钮
            button_account_info = ActionForm.Button(text="§l§5账户信息",icon="textures/ui/icon_steve",on_click=account_info())
            # 交易市场
            button_market = ActionForm.Button(text="§l§5交易市场",icon="textures/ui/icon_steve",on_click=market_menu())
            # 商品上架
            button_addgoods = ActionForm.Button(text="§l§5上架商品",icon="textures/ui/icon_steve",on_click=add_goods_menu())
            # 市场主菜单
            form = ActionForm(
                title="§l§b市场菜单",
                content=f"§l§o§b欢迎光~临!",
                buttons=[button_account_info,button_market,button_addgoods]
            )
            self.server.get_player(sender.name).send_form(form)

        return True
    
    # 用于绿宝石开启菜单
    @event_handler
    def open_menu(self,event:PlayerInteractEvent):
        current_time = time.time()
        if current_time - self.last_command_time < 2:  # 2秒内不重复执行
            return
        item_str = str(event.item)
        item_name = r"ItemStack\(minecraft:emerald\s+x\s*\d+\)"
        #event.player.send_message(f"{self.server.get_player(event.player.name).inventory.get_item(8)}")
        if re.match(item_name, item_str):
            player = event.player
            player.perform_command("market")
            self.last_command_time = current_time  # 更新上次执行时间
            # 调试
            #if self.testgoods("yuhang 2006") == False:
            #    self.add_goods("yuhang 2006","minecraft:iron_sword",1,"minecraft:emerald",20)
            return