from endstone.command import Command, CommandSender
from endstone.plugin import Plugin
import json
import os
# 插件初始化部分

fmdata = "plugins/freemarket"
moneydata = "plugins/freemarket/moneydata.json"

# 创建数据文件夹
if not os.path.exists(fmdata):
    os.makedirs(fmdata)
# 创建货币数据文件    
if not os.path.exists(moneydata):
    with open(moneydata, 'w',encoding='utf-8') as file:
        json.dump({}, file)

# 用于用户注册的函数
def add_user(playername,username,money=0):
    """
    注册用户信息
    playername: 玩家名
    username: 玩家注册的用户名
    money: 用户资金,默认为0
    """
    # 读取现有的经济数据
    with open(moneydata, "r",encoding='utf-8') as f:
        data = json.load(f)
    # 注册用户信息
    data[playername] = {"username": username, "money": money}
    # 将修改后的数据写入文件
    with open(moneydata, "w",encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    msg = f"您已成功注册服务器交易账号,账号名为 {username}"
    return msg

# 用于检测玩家是否注册过服务器交易账号的函数
def testuser(playername):
    """
    检测玩家是否注册过服务器交易账号
    playername: 玩家名
    """  
    # 读取现有的经济数据
    with open(moneydata, "r",encoding='utf-8') as f:
        data = json.load(f)
    # 检查玩家是否注册
    if playername not in data:
        return False
    else:
        return True
    
# 用于用户资金变动的函数
def change_money(playername,action,money=0):
    """
    用户资金变动
    playername: 玩家名
    action: 对用户资金的操作,增加为add,减少为less
    money: 用户资金的更改额度,默认为0
    """
    # 读取现有的经济数据
    with open(moneydata, "r",encoding='utf-8') as f:
        data = json.load(f)
    # 获取玩家账户资金
    nowmoney = data[playername]["money"]
    # 对玩家资金进行运算
    if action == "add":
        aftermoney = nowmoney + money
    elif action == "less":
        aftermoney = nowmoney - money
    else:
        msg = "无经济操作"
        return msg
    # 更改玩家资金
    data[playername]["money"] = aftermoney
    # 将修改后的数据写入文件
    with open(moneydata, "w",encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    msg = f"玩家 {playername} 的账户已{"增加" if action == "add" else "减少"}了{money}货币,现账户余额为{aftermoney}"
    return msg

# 用于用户重命名的函数
def rename_account(playername,username):
    """
    用户重命名
    playername: 玩家名
    username: 新用户名
    """
    # 读取现有的经济数据
    with open(moneydata, "r",encoding='utf-8') as f:
        data = json.load(f)

    if data[playername]["username"] == username:
        msg = "新用户名与老用户名一致,无需更改"
        return msg
    old_username = data[playername]["username"]
    # 更改玩家用户名
    data[playername]["username"] = username
    # 将修改后的数据写入文件
    with open(moneydata, "w",encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    msg = f"玩家 {playername} 的账户 {old_username} 已重命名为 {username}"
    return msg

# 用于删除用户的函数
def del_account(playername):
    """
    删除玩家账户
    playername: 玩家名
    """
    # 读取现有的经济数据
    with open(moneydata, "r",encoding='utf-8') as f:
        data = json.load(f)

    del data[playername]
    # 将修改后的数据写入文件
    with open(moneydata, "w",encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    msg = f"玩家 {playername} 的账户已被删除"
    return msg



class freemarket(Plugin):
    api_version = "0.5"
    
    def on_load(self) -> None:
        self.logger.info("on_load is called!")

    def on_enable(self) -> None:
        self.logger.info("on_enable is called!")

    def on_disable(self) -> None:
        self.logger.info("on_disable is called!")

    commands = {
        "account": {
            "description": "对玩家账号进行操作 --用法 /account 玩家名 操作:[add less create rename del] 金额/用户名",
            "usages": ["/account [msg: message] [msg: message] [msg: message]"],
            "permissions": ["freemarket.command.changemoney"],
        }
    }
    permissions = {
        "freemarket.command.account": {
            "description": "对玩家账号进行操作",
            "default": "op", 
        }
    }
    
    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name == "account":
            try:
                playername = args[0]
                action = args[1]
                # 检查玩家是否存在账号
                if testuser(playername) == False:
                    # 操作为create时创建默认账号
                    if action == "create":
                        msg = add_user(playername,username="默认昵称",money=0)
                    else:
                        sender.send_error_message(f"玩家 {playername} 没有服务器交易账号")
                        return
                else:
                    if action == "add":
                        msg = change_money(playername,action,money=float(args[2]))
                    elif action == "less":
                        msg = change_money(playername,action,money=float(args[2]))
                    elif action == "create":
                        sender.send_error_message("该玩家的账号已存在,无需创建")
                        return
                    elif action == "rename":
                        msg = rename_account(playername,username=args[2])
                    elif action == "del":
                        msg = del_account(playername)
            except:
                sender.send_error_message("格式错误")
                return
                #else:
                #    msg = change_money(playername,action="add",money=114154)
                
            sender.send_message(f"{msg}")

        return True